#!/bin/bash
rm -rf /home/container/tmp/*

#echo "⟳ Starting PHP-FPM..."
#/usr/sbin/php-fpm8 --fpm-config /home/container/php-fpm/php-fpm.conf --daemonize
#cd /home/container/webroot/redmine
#bundle install --without development test --path vendor/bundle
#bundle exec rake generate_secret_token
#RAILS_ENV=production bundle exec rake db:migrate
#RAILS_ENV=production REDMINE_LANG=en bundle exec rake redmine:load_default_data
#cd /home/container/webroot/redmine
#echo "⟳ Starting passenger"
#passenger start -e production
#echo "✓ Successfully started"
#echo "⟳ Starting Nginx..."
#echo "✓ Successfully started"
/opt/nginx/sbin/nginx -c /home/container/nginx/nginx.conf -p /home/container/




