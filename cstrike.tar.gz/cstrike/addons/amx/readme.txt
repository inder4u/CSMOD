AMX Mod 2010.1 - WIN32/LINUX - STEAM
=============================================================================
   I.   Installation
  II.   Commands
 III.   Writing Plugins
  IV.   Compiling Plugins
   V.   Settings
  VI.   Troubleshooting, FAQ
 VII.   Changelog


         For more indepth setup and instructions for AMX go here:
                        http://amxmod.net/doc/


I. Installation
=============================================================================
You *must* have Metamod/Metamod-P 1.19 or higher installed to use this plugin.

"$moddir" is your Mod directory, f.e. "cstrike" if you run Counter-Strike.

1. Download MetaMod from http://www.metamod.org or MetaMod-P from
   http://prdownloads.sourceforge.net/metamod-p/ and install it
   following its instructions.

   NOTE: This package comes with MetaMod-P 1.21p37.
         If you don't have MetaMod yet, just rename the file
         $moddir/addons/metamod/sample_plugins.ini to plugins.ini.
         Otherwise, merge sample_plugins.ini with your plugins.ini.
         You can also overwrite addons/metamod/dlls/metamod.dll
         or addons/metamod/dlls/metamod.so
         with a more recent or customized version.

   Just to make sure, after installation, you should get:
     $moddir/addons/metamod/dlls/metamod.dll
     $moddir/addons/metamod/dlls/metamod.so
     $moddir/addons/metamod/plugins.ini

   In $moddir/liblist.gam file instead of:
     gamedll "dlls\mp.dll"
     gamedll_linux "dlls/cs_i386.so"

   You should have:
     gamedll "addons\metamod\dlls\metamod.dll"
     gamedll_linux "addons/metamod/dlls/metamod.so"


2. Unzip this file to $moddir with directory structure.
   You should get:
     $moddir/addons/amx/dlls/amx_mm.dll
     $moddir/addons/amx/dlls/amx_mm_i386.so
     $moddir/addons/amx/modules/csstats.dll
     $moddir/addons/amx/modules/csstats_i386.so
     $moddir/addons/amx/modules/fun.dll
     $moddir/addons/amx/modules/fun_i386.so
     $moddir/addons/amx/modules/VexdUM.dll
     $moddir/addons/amx/modules/VexdUM_i386.so
     $moddir/addons/amx/modules/mysql.dll
     $moddir/addons/amx/modules/mysql_i386.so
     $moddir/addons/amx/modules/geoip.dll
     $moddir/addons/amx/modules/geoip_i386.so
     $moddir/addons/amx/modules/sockets.dll
     $moddir/addons/amx/modules/sockets_i386.so
     $moddir/addons/amx/examples/source/default/*.sma
     $moddir/addons/amx/examples/include/*.inc
     $moddir/addons/amx/logs/...
     $moddir/addons/amx/config/plugins.ini
     $moddir/addons/amx/config/modules.ini
     $moddir/addons/amx/plugins/*.amx
     $moddir/addons/amx/...


3. Open "addons/metamod/plugins.ini" and make sure it contains
   (line with ; char is a comment):
     ; AMX Mod
     win32 addons/amx/dlls/amx_mm.dll
     linux addons/amx/dlls/amx_mm_i386.so
     

4. Open "addons/amx/config/modules.ini" and add
   these lines (if not already exist there):
     ;csstats
     ;fun
     ;VexdUM
     ;mysql
     ;geoip
     ;sockets


5. Make sure you have AMX scripts files under "addons/amx/plugins" path.

   They have to be declared in addons/amx/config/plugins.ini.

   You can also override plugins list filename by setting
   amx_plugins localinfo as a HLDS parameter.
   (f.e. +localinfo amx_plugins "addons/amx/plugins.ini")


NOTES:
   . MetaMod can use "addons/metamod/plugins.ini" or
     "metamod.ini" file to specify its plugins. If you
     don't have any then create one or rename provided sample_plugins.ini
     to plugins.ini


II. Commands
=============================================================================
To see the list of all available commands for AMX Mod,
type "amx" in the server console. With these commands
you can check version of AMX, list all cvars
and server commands registered by plugins; pause,
unpause plugins; display status and additional info about
plugins and modules.

If none of them works or you get an error message then
you haven't installed AMX properly.


III. Writing Plugins
=============================================================================
For Small/Pawn basics read: http://www.compuphase.com/pawn/pawn.htm#DOWNLOAD_DOCS

To learn about AMX Mod script functions (natives) go to
"addons/amx/examples/include" path and read contents of all files
with "inc" extension. A good idea is reading code of scripts
published on AMX web site: http://amxmod.net/plugins.php
You can also read tutorials and ask for help here:
http://djeyl.net/forum/index.php?showforum=40

Scripting in AMX Mod is the same as it is in AdminMod.
However plugins from first won't run under second and vice versa.


IV. Compiling Plugins
=============================================================================
Enter to "addons/amx/examples" path where you will find files "sc.exe"
for win32 and "sc" for linux. These are compilers for AMX scripts.

To compile your script (files with "sma" extension), put it into
"addons/amx/examples" directory and run proper compiler passing the
name of your script filename as an argument (for win32 you may run
"compile.bat" and under linux "compile" to get all files with "sma"
extension compiled in "addons/amx/examples/compiled" directory).
You can also drag the .sma files onto the compile_drag&drop.bat.

Plugins compiled under win32 work on linux and vice versa.


V. Settings
=============================================================================
AMX has several options which allow you to run the same program
on multiple sessions. To achieve it you have to run your dedicated server
with additional parameters in command line or use the paths.ini file that is
located in "addons/amx/config" directory.

Here is a list with short description:
amx_basedir - By default set to "addons/amx". This localinfo is used
by scripts written in Small to get location of amx folder.

amx_configdir - By default set to "addons/amx/config". This localinfo is used
by scripts written in Small to get location of their configuration files.

amx_mapsconfigdir - By default set to "addons/amx/config/maps". Describes folder where
AMX per-map configuration files are stored.

amx_langdir - By default set to "addons/amx/lang". Describes folder where
lang files are stored.

amx_modulesdir - By default set to "addons/amx/modules". Describes folder where
AMX modules are stored.

amx_pluginsdir - By default set to "addons/amx/plugins". Describes folder where
AMX plugins are stored.

amx_mapspluginsdir - By default set to "addons/amx/config/maps_plugins". Describes folder where
AMX per-map plugin configuration files are stored.

amx_logdir - By default set to "addons/amx/logs". Describes folder where
logs sent by log_to_file/log_amx/report_error natives are stored.

amx_modules - By default set to "addons/amx/config/modules.ini". Describes
a file with list of AMX modules to load.

amx_plugins - By default set to "addons/amx/config/plugins.ini". Describes
a file with list of AMX plugins to load. 

amx_usejit - By default set to "config". Sets when plugins have to be used
with the JIT (Just-In-Time compiler, introduced in v0.9.9, allowing 10+
times faster plugin execution). This can take three values: 'never', 'config'
and 'always'. 'never' will run all the plugins with the (old) (slow)
interpreter, 'always' will run them all with the JIT, and 'config' (which is
the default) will let you specify 'nojit' right after any plugin
filename in addons/amx/config/plugins.ini if you don't want it to be run by
the JIT.

amx_vault - By default set to "addons/amx/config/vault.ini". This is the
location of the file where vault data are stored.

csstats_score - By default set to "addons/amx/plugins/csstats.amx". This is
the location of the file by which a score is evaluated.

csstats - By default set to "addons/amx/modules/csstats.dat". This is the
name of the file where rank is stored in a binary form.

All these settings above should be put in a command line with +localinfo
in front. For example:
./hlds_run -game cstrike +localinfo amx_logdir "addons/amx/logs_27016"

There is also another possibility to configure AMX. Use the paths.ini file
that is located in the config folder of AMX:

; Configuration file for AMX Mod
amx_basedir addons/amx
amx_configdir addons/amx/config
amx_mapsconfigdir addons/amx/config/maps
amx_langdir addons/amx/lang
amx_modulesdir addons/amx/modules
amx_pluginsdir addons/amx/plugins
amx_mapspluginsdir addons/amx/config/maps_plugins
amx_logdir addons/amx/logs

amx_modules addons/amx/config/modules.ini
amx_plugins addons/amx/config/plugins.ini
amx_vault addons/amx/config/vault.ini

csstats_score addons/amx/plugins/csstats.amx
csstats addons/amx/modules/csstats.dat

Now you can run a server with: +localinfo amx_cfg "addons/amx/config/paths_27016.ini"


New settings have been added to the paths.ini file:

; Modules autoloading (0 or 1)
autoload_modules 1

; Plugin optimization flags - add these up to get what you want.
; Lowering these may stop crashes on very old CPUs.
; Set 65536 to disable optimizer, NOT 0!
; Credits: AMX Mod X Dev Team
; *************************************************************
; 1 - float arithmetic
; 2 - float comparisons
; 4 - float rounding
optimizer 7


VI. Troubleshooting, FAQ
=============================================================================
The best place to ask a question and get an answer is to go to the
amxmod.net site or forum. But if one of them is not available you can read the attached 
FAQ or the AMX Mod HTML documentation (see amx/docs folder or go to http://amxmod.net/doc/).

Here is a bunch of most common questions.

Q: I get "[AMX] Native not found: xxx (plugin "xxx")" and
   a plugin name given in this message is not loaded properly.
A: This is because you have not installed properly modules, which
   extend functionality of AMX. Type 'amx modules' and 'meta list' to
   get a list of modules you run.

Q: How do I add a new admin account?
A: Enter to "addons/amx/config/users.ini" and read carefully comments and
   examples posted below. Example account looks like this:
   "My Name" "my_password" "abcdefghijklmnopqrstuvwy" "a"
   Where first parameter can be SteamID, name or ip, second is a password
   which have to be set in config file of a user, third parameter is an
   access and last parameter are flags. Two last parameters are briefly
   described in comments of users.ini file. Make sure that in front
   of account line there is no ; char.
   Otherwise, you can also use the "amx_addadmin" command to give at anyone
   you want admin powers. However, if you are in game and you never have got any
   admin power you must use the command from server console (if you have rcon password).

Q: What should I treat as authid/SteamID?
A: Enter to game as player and type in your console "status".
   You will get a response with some details about you and a few other
   currently connected players. Your authid/SteamID should look for
   example like "STEAM_0:0:1234" or "STEAM_0:1:2323". This is the value you should put
   in the first field of an admin account in "addons/amx/config/users.ini".
   If you have a listenserver, uncomment the "loopback" line in users.ini.

Q: Where can I find more details about plugins?
A: Read comments and a content of plugin_init function in a plugin
   source (*.sma file). Also the useful commands are:
   amx_help - Lists all commands available for an admin account.
   With this command you get an answer of how to configure stats,
   pause/unpause plugins and use admin commands.
   amx cmds - This should be typed in a server console. It lists all
   commands registered by plugins with their access flags.
   amx cvars - This should be typed in a server console. It lists all
   cvars registered by plugins.

Q: I have more questions, where can I ask them?
A: Ask in "Support / Help" section of amxmod.net forum (if available). But make
   sure that an answer is not already given in stickied posts.
   Also, you can open the FAQ.txt file or read the HTML documentation
   (amx/docs folder).


VII. Changelog
=============================================================================

AMX Mod 2010.1-fix3
-----------------------------------------------------------------------------
Core:
o fixed forward server_changelevel not working

VexdUM:
o fixed forward alertmessage not working
o added forward addtofullpack_post


AMX Mod 2010.1-fix2
-----------------------------------------------------------------------------
Core:
o fixed a crash
o updated set_cvarptr_float for a better set of the value specifed


AMX Mod 2010.1-fix1
-----------------------------------------------------------------------------
Core:
o fixed a crash (it happened under linux and with the latest ValVe update of February 13 2013)
o fixed get_msg_arg_string not worked correctly (also a possible crash)
o fixed set_cvarptr_<num|float> which didn't properly set the new value

VexdUM:
o removed cvar sv_friendlyfire (Damage functions use now mp_friendlyfire)
o renamed cvars sv_knocknack<1|2> into amx_knockback<1|2>
o improved a bit the Damage functions to take effect properly on others mods than CS (also to set damage on owner)


AMX Mod 2010.1
-----------------------------------------------------------------------------
Core:
o added native log_amx
o updated native register_event
o fixed native arrayset
o added native arraysetfloat
o added native set_cvarptr_string
o added native change_cmdaccess
o updated natives get_plugincmd and get_plugincmdsnum
o added natives float_to_str/floattostr
o updated native format_args
o moved get_msg_block/set_msg_block from VexdUM to AMX core
o added natives emessage_* and ewrite_*
o added natives register_message/unregister_message
o added natives get_msg_arg_*/set_msg_arg_* and get_msg_args
o added natives get_msg_origin/set_msg_origin
o added native set_msg_entity
o you can disable all previously loaded plugins or load a new plugin file, with these keywords (to be used in a plugins ".ini" file):
  #disable_all : clear all plugins found in the plugins.ini files previously analyzed
  #include_file <filepath> : load plugins specified in <filepath> (the path is relative to the AMX Mod config folder)
o you can have one or many group file(s) to regroup into the same file the list of the plugins you want to load for a group of maps (that allows you to simplify your plugins editing):
  Create in the "amx/config/maps_plugins" folder a <name>.ini file and put the names of your plugins inside that file.
  Then, in the "amx/config/maps_plugins/mapgroups.ini" file, write your settings using the following format:
    <plugins file name> <mapname>
  For example:
    mapgroup1.ini cs_italy
    mapgroup1.ini de_wimbeldon
    mapgroup1.ini crate_warehouse
    mapgroup2.ini de_storm
    mapgroup2.ini de_chateau
  Now, for instance, if the map "de_storm" is loaded, the mapgroup2.ini file will be loaded, but the prefix_*.ini file will not (prefix_de_.ini for this example).
  So, only the de_storm.ini file will be loaded after the mapgroup2.ini file (note: the group files can be named otherwise).
  In the normal way, the plugins files are loaded in the following order:
    amx/config/plugins.ini
    amx/config/plugins-*.ini
    amx/config/maps_plugins/prefix_*.ini
    amx/config/maps_plugins/mapname.ini
  But, if a map is set in the mapgroups.ini file, the new order will be:
    amx/config/plugins.ini
    amx/config/plugins-*.ini
    amx/config/maps_plugins/groupfile.ini
    amx/config/maps_plugins/mapname.ini
o modules are autoloaded if forwards are found in the plugins (previously only the natives were checked)
o added possibility to list the commands/cvars declared by a specified plugin (optional argument from the "amx" server command)
o modified cvars order (from "amx" server command; it also affects the cvars list of the "amx_plugcvarmenu" command)
o removed client command amxmodules
o added cvar amx_log_to_hl_logs

Fun:
o added natives get_client_listen/set_client_listen
o removed cvar fun_version

VexdUM:
o added forward addtofullpack
o added natives get_offset_float/set_offset_float
o added native dllfunc
o added natives get_es/set_es
o added native forward_return

GeoIP:
o fixed countries detection
o updated countries/GeoIP.dat

MySQL Access:
o fixed virus detection (which was a false positive and present since AMX 2006.3 release)

Plugins:
o modified "show admins activity" feature for all the plugins (this function now uses a stock from amxmisc.inc)
o added "SERVER" (will be translated according to your personal/server language) to replace the server name (admins activity, chat commands, AMX logs...)
o admin
  - added server command amx_changecmdaccess
  - added server command amx_exportcmdaccess
  - added cvar amx_realadmin_flags
o adminchat
  - added AMX Mod default blue color (use "a", "amx" or "amxmod" for the "color" argument of the chat command)
o antiflood
  - removed admins checking

Includes:
o amxconst.inc
  - added #define COLORED_ACTIVITY
  - removed #define FLAGS_SHOW_ACTIVITY3 and #define FLAGS_SHOW_ACTIVITY4
  - added #define ADMIN_ADMIN
  - added #define MENU_KEY_*_INT
o amxmisc.inc
  - updated access and cmd_access
  - updated is_user_admin, is_user_realadmin and is_user_masteradmin
  - updated has_flags and has_all_flags
  - updated show_activity
  - added show_activity_color
  - updated client_print_color
  - updated get_amx_version
o updated amxmodx_to_amx.inc
o updated cstrike.inc
o added message.inc
o string.inc
  - updated trim_imp
  - fixed strtok

Configuration:
o amx.cfg
  - added amx_realadminflags
  - updated amx_show_activity (modified 3 and 4, added 5)
  - added amx_log_to_hl_logs
o added mapgroups.ini file in the amx/config/maps_plugins folder
o added four maps groups files (mapgroup*.ini) by default in the amx/config/maps_plugins folder (to use with the "mapgroups.ini" file)

Misc:
o updated amx_compiler.exe
o added amx_compiler_colored_activity.exe in the CS package

Documentation:
o updated .txt and HTML documentations

*****************************************************************************
Special thanks to:
siG for his translation job in German language for:
  - config files
  - new documentations

*****************************************************************************
Some natives were added from AMX Mod X to facilitate the conversion of
AMX Mod X plugins to AMX Mod. Here is the list. Credits go to AMX Mod X Dev Team.

set_cvarptr_string
emessage_*/ewrite_*

dllfunc
get_es/set_es

*****************************************************************************


AMX Mod 2006.4 RC2
-----------------------------------------------------------------------------
Core, Fun, VexdUM, CSStats, DoDXMod, GeoIP, MySQL Access, Sockets:
o no changes (should be done later)

Provided binaries:
o added Metamod-P 1.19p32 to the default packages

Plugins:
o added optimizations
o added missing documentations to the top of the .sma files, then also updated
o admin
  - fixed amx_makeadmin command used from rcon access, and modified the some flags couldn't be given (rcon and supreme)
o adminchat
  - added color chat for the standard chat commands such as amx_say, amx_chat, amx_psay and say_team @ (only available for CS 1.6 or CZ)
  - fixed "say_team @" command access (player to admin(s) private chat)
  - any admin can now see the standard chat messages, even if he has not the admin chat access
  - removed commands without the "amx_" prefix (useless duplicated commands)
o admincmd
  - added command amx_clcmd
  - added cvar amx_show_clcmds (these client commands can be visible only from admin activity messages, therefore only if amx_show_activity cvar is not set to 0)
  - modified required admin flags to ban a player with immunity (rcon + supreme flags needed)
  - removed losing frag when you slay a player
  - added restriction to the amx_extendmap command if mp_timelimit cvar is set to 0
  - added admin in-game information message to the amx_cvar command (for "add" argument)
  - added displaying port to the amx_showip command
o cmdmenu
  - modifications to the amx_plugcmdmenu/amx_plugcvarmenu commands:
    - added displaying plugin menu after the execution of a command/cvar
    - added possibility to get back to the primary plugins commands/cvars menu
    - modified submenus titles (each title contain the plugin name)
o imessage
  - fixed hostname translation (if #define USE_TRANSLATIONS enabled)
  - added possibility to use colors names such as white, red, green, blue... (which have to be only writed in English language to work properly)
  - enabled translation feature by default (read amx/lang/imessage.txt for more infos)
  - added AMX default sentences already translated into amx/lang/imessage.txt
o language
  - added visibility of both commands directly from amx_help command
o mapchooser
  - fixed crash which could be caused by a low maps number inside the maps.ini/mapcycle file
  - fixed nominations mode (when amx_nominfromfile was set to 0)
  - fixed displaying maps in the amx_listmaps command
  - added #define FLAG_AMX_LISTMAPS to the top of the .sma file
o mapsmenu
  - removed possibility to get several times the same map in your Maps Menu/VoteMap Menu (due by a multiple copy of the same map in your maps file)
  - fixed maps descriptions in their menus
o menufront
  - menus created from the amx_addmenuitem command:
    - added supreme admin support
    - admins names are colored in red like the other AMX menus
  - changed amx_teammenu command access flag to ADMIN_SLAY
  - changed amx_clcmdmenu command access flag to ADMIN_MENU
o plmenu
  - modified required admin flags to ban a player with immunity (rcon + supreme flags needed)
  - changed amx_teammenu command access flag to ADMIN_SLAY
  - changed amx_clcmdmenu command access flag to ADMIN_MENU
o scrollmsg
  - added possibility to define the color or a random color (amx_scrollmsg "Text" time 000100255/amx_scrollmsg "Text" time ?)
o telemenu
  - a player can be teleported on a climb, it won't be blocked anymore
  - changed amx_teleportmenu command access flag to ADMIN_LEVEL_A
o welcomemsg
  - updated visible addons list
o restmenu
  - added translations for subtitles of categories
  - updated map settings feature (load/save)
o statsx
  - admin names are colored in red in the players stats menu, but only if the menu is opened by an admin
o miscstats
  - it's now possible to easily add/remove stats messages
  - fixed bad statistic loading if VexdUM module wasn't loaded ("Suicide" stat)
o dodx_stats
  - admin names are colored in red in the players stats menu, but only if the menu is opened by an admin
  - it's now possible to easily add/remove stats messages
  - fixed bad statistic loading if VexdUM module wasn't loaded ("Suicide" stat)

Includes:
o amxconst.inc
  - added FLAGS_SHOW_ACTIVITY_3 and FLAGS_SHOW_ACTIVITY_4, to easily edit which admins can see the activity messages when amx_show_activity cvar is set to 3 or 4
  - added #define MENU_KEY_ALL 1023
  - added #define HLI_* and HLW_* (or * is a item/weapon name of a Valve mod)
  - added #define CSW_VEST and #define CSW_VESTHELM
  - added #define VOL_LOW and #define VOL_HIGH
o amxmisc.inc
  - updated cmd_target
  - added is_user_realadmin
  - added is_user_masteradmin
  - added has_flag
  - added has_all_flags
  - updated show_activity
  - added client_print_color
  - added is_playerid_valid
  - added get_amx_version
  - added is_map_running
  - updated build_path
o fixed and updated amxmodx_to_amx.inc (~ 200 new functions! Read the top of this file for your AMXX to AMX plugins conversions)
o updated cstrike.inc
o float.inc
  - added floatmin
  - added floatmax
  - added floatclamp
o message_const.inc
  - added #define SVC_* (or * is a message type for message_begin())
o string.inc
  - added charsmax
  - added isquote
  - added trim_imp
o Vexd_Utilities.inc
  - added GetSpeak
  - added ENT_SetSize
o VexdUM_const.inc
  - added #define FTRACE_SIMPLEBOX (1<<0)
  - added #define SF_* (or * is a name of a spawn flag)
  - added #define CONTENT_* (or * is a name of a content type)
  - added #define FEV_* (or * is a name of a playback event flag)
o Xtrafun_to_Vexd.inc
  - added get_grenade_index
o added xs.inc by Pavol "PM" Marko
o added missing descriptions for forwards/natives/stocks/defines functions then updated them (for all .inc files)
o changed forwards/natives/stocks order and reclustering by similar categories (for all .inc files that needed)

Lang:
o fixed and updated all lang files, with proper punctuation, and added missing sentences for each language
o added Turkish translation by GencKafe.Net Team
o renamed statslog.txt to stats_logging.txt
o renamed dodx_statslog.txt to dodx_stats_logging.txt

Configuration:
o amx.cfg
  - moved amx_mode to the top of the file
  - updated amx_show_activity (4: show with name, but only to admins with "l" flag (AMX rcon access))
  - added amx_show_clcmds
  - added information above the amx_scrollmsg command
  - added information above the amx_imessage commands
o changed default commands order into clcmds.ini file
o added this message into clcmds.ini, cmds.ini, configs.ini and speech.ini files:
  ; You can use \' to replace a quote inside your command (see speech.ini file for example).
o cvars.ini
  - added new cvars and values for CS and DoD packages
o maps.ini
  - added Condition Zero default maps and their descriptions for CS package
o paths.ini
  - added amx_mapsconfigdir addons/amx/config/maps
o plugins.ini
  - changed the order of the plugins
o added second plugins.ini file (plugins-two.ini), could be usefull for some tests and more
o users.ini
  - updated help with new required access flags for commands
  - added information about the "l" access flag (RCON acces by AMX), to the end of the file
o added per-maps config files for all CS/CZ and DoD default maps in the CS/DoD packages (amx/config/maps folder) and some prefix_*.cfg files
o added per-maps plugin config files for all CS/CZ and DoD default maps in the CS/DoD packages (amx/config/maps_plugins folder) and some prefix_*.ini files
o updated help for all config files

Misc:
o added AMX sound package by default in the CS and DoD packages

Documentation:
o updated .txt and HTML documentations

*****************************************************************************
Special thanks to:
GencKafe.Net Team for their translation job of the new Turkish language.
siG for his translation job in German language for:
  - config files
  - missing translations into some config files
  - new documentations

*****************************************************************************
Some stocks/defines were added from AMX Mod X to facilitate the conversion of
AMX Mod X plugins to AMX Mod. Here is the list. Credits go to AMX Mod X Dev Team.

#define HLI_* and HLW_*

has_flag
has_all_flags

floatmin
floatmax
floatclamp

#define SVC_*

charsmax

#define FTRACE_SIMPLEBOX
#define SF_*
#define CONTENT_*
#define FEV_*

*****************************************************************************


AMX Mod 2006.3
This release includes code from AMX Mod X.
-----------------------------------------------------------------------------
Core:
o modified modules API (merged from AMX Mod X)
o added optimizations to AMX and its modules (some merged from AMX Mod X)
o added float optimizations (merged from AMX Mod X)
o added modules autoloading
o fixed some problems with modules
o added natives set_cvarptr_/get_cvarptr_ and get_cvar_pointer (merged from AMX Mod X)
o added native print_to_admins
o added native load_module
o added native formatex (merged from AMX Mod X)
o fixed crashes that happened when chinese characters were used in the lang files
  (if you want to translate AMX to chinese, you have to save the lang files as "UTF-8" format)
o you can have more than one plugins.ini file: the other files must begin with "plugins-"
  and end with ".ini" and must be in the amx/config folder (fe: plugins-test.ini)
o you can have per-map plugin configuration files and general plugin configuration files (idea from AMX Mod X):
  use the amx/config/maps_plugins folder, inside create some mapname.ini files or
  prefix_*.ini files (fe: de_dust.ini, de_inferno.ini, prefix_cs_.ini, prefix_scoutz.ini).
  These files will be loaded in the following order:
    amx/config/plugins.ini
    amx/config/plugins-*.ini
    amx/config/maps_plugins/prefix_*.ini
    amx/config/maps_plugins/mapname.ini
  All the plugins declared in these files will be loaded unless you add the "disabled" keyword after the
  plugin filename in the .ini file (idea from AMX Mod X):
    myplugin.amx disabled
    telemenu.amx disabled
    myprecacheplugin.amx disabled
  In that case, if the plugin was previously declared (in the same or another .ini file), it won't be loaded.
  Thanks to that, you can disable some plugins that precache lots of things on certain maps for instance
  (useful if these plugins make the server crash when these maps are loaded).
o changed format of the modules.ini file: you can use modulename.dll, modulename_i386.so or just modulename.
o fixed write_file native for servers hosted on VeryGames (french game server provider that does not allow
  amx to create a temp file...)
o renamed "amx_modules" client command to "amxmodules"
o added cvar amx_modules (amx_version will only display "2006.3")

Fun:
o added native strip_user_weapons (merged from AMX Mod X)
o added optimizations

VexdUM:
o fixed radius_damage
o added forward alertmessage
o added forward getgamedescription
o added native setgamedescription
o added optimizations

CSStats:
o when csstats_maxsize is reached, stats are not reset, "csstats_maxsize" stats are saved to the csstats.dat file
o you can use a csstats.dat file created by amxmodx (it was already possible with amx 2005 but I never mentioned it)
o added forwards damage_info, death_info, grenade_throw,
  bomb_planting, bomb_planted, bomb_exploded, bomb_defusing, bomb_defused (idea from AMX Mod X)
o fixed file parser (merged from AMX Mod X)
o added csstats_savesv command in order to export csstats.dat to a tab or semicolon separated values file:
  csstats_savesv "path/file" 0 : saves csstats.dat to "path/file" (tab separated values)
  csstats_savesv "path/file" 1 : saves csstats.dat to "path/file" (semicolon separated values)
o added optimizations

DoD XMod:
o when dodstats_maxsize is reached, stats are not reset, "dodstats_maxsize" stats are saved to the dodstats.dat file
o added natives dod_set_user_ammo and dod_get_user_ammo (merged from AMX Mod X)
o fixed file parser (merged from AMX Mod X)
o added dodstats_savesv command in order to export dodstats.dat to a tab or semicolon separated values file:
  dodstats_savesv "path/file" 0 : saves dodstats.dat to "path/file" (tab separated values)
  dodstats_savesv "path/file" 1 : saves dodstats.dat to "path/file" (semicolon separated values)
o added optimizations

GeoIP:
o fixed GeoIP.dat
o updated GeoIP.c and GeoIP.h

Plugins:
o added optimizations
o moved important settings to the top of the .sma file so that you can easily get access to them and modify them
  Example from admin.sma:
  /******************************************************************************/
  // If you change one of the following settings, do not forget to recompile
  // the plugin and to install the new .amx file on your server.
  // You can find the list of admin flags in the amx/examples/include/amxconst.inc file.

  #define MAX_ADMINS 64

  #define FLAG_AMX_ADDADMIN     ADMIN_RCON
  #define FLAG_AMX_REMOVEADMIN  ADMIN_RCON
  #define FLAG_AMX_MAKEADMIN    ADMIN_RCON
  
  /******************************************************************************/
o added back NO_STEAM support (for CS 1.5 users)
o it is now displayed name<userid><steamid><ip> instead of name<userid><steamid><> in the logs
o admin
  - when you use amx_addadmin, if the player is in game, his name is added as a comment to the users.ini file
o adminchat
  - added cvar amx_chat_anonymous (read amx.cfg)
  - for people who don't know these shortcuts:
    say @@@message = amx_scrollsay message
    say @@@ymessage = amx_scrollsayy message
    say @@message = amx_csay message
    say @@ymessage = amx_csayy message
    say @message = amx_tsay message
    say @ymessage = amx_tsayy message
    say ###message = amx_say message
    say ###ymessage = amx_sayy message
    say ##message = amx_chat message
    say #message = amx_psay message
    say #ymessage = amx_psayy message
    say $$$message = amx_fsay message
    say $$$ymessage = amx_fsayy message
    say $$message = amx_flicksay message
    say $$ymessage = amx_flicksayy message
    say $message = amx_fxsay message
    say $ymessage = amx_fxsayy message
o admincmd
  - reason is displayed to players who are banned with amx_ban
  - if it is a lan server, amx_ban <name/#userid> will automatically ban by ip instead of steamid
  - added command amx_showip [name|#userid|authid]
o adminvote
  - fixed a bug
o imessage
  - you can use "?" to get a random color (amx_imessage "message" "?")
o mapsmenu
  - renamed cvar amx_mapsmenu_mapsloc to amx_mapmenu_mapsloc
  - added cvar amx_votemapmenu_mapsloc
o mapchooser
  - added amx_mapchooser_type 2
  - added cvar amx_mapchooser_mapsfile (read amx.cfg)
  - option 7 in the vote is now "7. Keep current nextmap: mapname" instead of "7. mapname"
  - amx_listmaps now also works when amx_nominfromfile is set to 0
	- a help message is displayed every 3mns to tell people they can nominate maps
    (when amx_mapchooser_type is set to 1)
o statsx
  - added #define NEW_SPEC_RANK_INFO to see players' rank in first person mode when you are spectator/dead
    (if you enable this #define you have to recompile the plugin, and it requires VexdUM)

Includes:
o amxconst.inc
  - added back #define NO_STEAM
  - added #define ADMIN_ALL 0
o updated cstrike.inc
o updated amxmodx_to_amx.inc

Configuration:
o amx.cfg
  - updated amx_show_activity (3: show with name, but only to admins)
  - added amx_chat_anonymous
  - renamed amx_mapsmenu_mapsloc to amx_mapmenu_mapsloc
  - added amx_votemapmenu_mapsloc
  - updated amx_mapchooser_type (2)
  - added amx_mapchooser_mapsfile
o modified modules.ini
o paths.ini
  - added amx_mapspluginsdir addons/amx/config/maps_plugins
  - added autoload_modules 1
  - added optimizer 7 (merged from AMX Mod X)
  
Misc:
o fixed amx_compiler.exe
o compiler
  - removed "local variable shadows a variable at a preceding level" warning (merged from AMX Mod X)
  - the variable names of forwards can be changed (merged from AMX Mod X)
  - fixed code generation bug (merged from AMX Mod X)

*****************************************************************************
Some features were added from AmxModX. Here is the list.
Credits go to AmxModX Dev Team.

modules API
float optimizer
bot detection improvement
the use of reinterpret_cast<cvar_t *> for get/set_cvarptr natives
native formatex
native strip_user_weapons
modification of native DispatchKeyValue
file parser fixes for CSStats/DoDXMod
Client_Damage and Client_Damage_End for CSStats
the use of StartFrame_Post for CSStats forwards
dod_set_user_ammo and dod_get_user_ammo for DoDXMod
compilation speed improvement
compiler modifications

*****************************************************************************


AMX Mod 2006.2
This release includes code from AMX Mod X.
-----------------------------------------------------------------------------
Core:
o modified native translate(sent[],dest) (added forcelang parameter to force the
  translation to a specific language)
o moved some vector natives from VexdUM to AMX core (idea from AMX Mod X)
o improved error logging
o fixed a bug in get_language_support

VexdUM:
o added forward setclientkeyvalue
o added forward keyvalue (merged from AMX Mod X)
o added native set_client_keyvalue
o added native copy_keyvalue (merged from AMX Mod X)
o experimental fix to avoid crashes when set_user_model is called on many players at once (cstrike only)

CSStats:
o added server command csstats_savetext (read the amx.cfg file to know how to use it)
o added server command csstats_loadtext (read the amx.cfg file to know how to use it)

DoD XMod:
o added server command dodstats_savetext (read the amx.cfg file to know how to use it)
o added server command dodstats_loadtext (read the amx.cfg file to know how to use it)

MySQL:
o changed mysql_query(sql, query[]) into mysql_query(sql, query[], {Float,_}:... )

Plugins:
o plmenu
  - added amx_unbanmenu
  - admin names are colored in red in the menus
o restmenu
  - fixed a bug in "drop restricted weapons at the end of the round" setting
o telemenu
  - admin names are colored in red in the menu

Includes:
o amxconst.inc
  - added new admin flags (read users.ini for more info):
      ADMIN_PERMBAN
      ADMIN_UNBAN
      ADMIN_SUPREME
o updated cmd_target (amxmisc.inc) with ADMIN_SUPREME flag
o added vector.inc

Lang:
added Brazilian Portuguese by masuda
added Norwegian by ggfl_empire
added Polish by KWo

Configuration:
o users.ini
  - added admin flag v - permanent bans
  - added admin flag w - amx_unban command
  - added admin flag y - supreme admin

*****************************************************************************
Some natives were added from AmxModX to facilitate the conversion of
AmxModX plugins to AmxMod. Here is the list. Credits go to AmxModX Dev Team.

native copy_keyvalue
forward keyvalue

*****************************************************************************


AMX Mod 2006.1
This release includes code from AMX Mod X.
-----------------------------------------------------------------------------
Core:
o added native query_client_cvar
o added native get_weaponid (merged from AMX Mod X)
o added native get_distance_f (merged from AMX Mod X)
o added native dir_exists (merged from AMX Mod X)
o added native arrayset (merged from AMX Mod X)
o added native mkdir (merged from AMX Mod X)
o added native fsqroot
o added native fpower
o added native flog
o added forward server_changelevel (merged from AMX Mod X)
o added cvar amx_langdebug

Fun:
o fixed set_user_maxspeed
o added native get_user_footsteps

VexdUM:
o fixed set_user_model
o added native trace_result (merged from AMX Mod X)
o added native trace_hull (merged from AMX Mod X)
o added native get_keyvalue (merged from AMX Mod X)
o added native get_decal_index (merged from AMX Mod X)
o added native call_think (merged from AMX Mod X)
o updated find_entity (see VexdUM.inc)

CSStats:
o removed cvar csstats_storagetype
o added new stats: Bomb Runner, Bomb Planted, Bomb Exploded, Bomb Defusing,
  Bomb Defused, Hostages Touched, Hostages Rescued, Was Vip, Escaped As Vip
  Killed Vip, Suicides, Playtime

DoD XMod:
o removed cvar dodstats_storagetype

MySQL:
o added native mysql_getresult (merged from AMX Mod X)
o added native mysql_insert_id
o added native mysql_affected_rows
o added native mysql_num_fields
o added native mysql_num_rows
o added native mysql_field_name (merged from AMX Mod X)

Provided binaries:
o added MetaMod-P 1.19p28 to the default packages
o added MySQL module to the default packages

Plugins:
o admin
  - added amx_removeadmin
o admincmd
  - added amx_extendmap
  - added amx_showrcon (merged from AMX Mod X)
o adminslots
  - added a new mode (amx_reservation 4)
  - added cvar amx_reservedslots
  - added cvar amx_hideslots
o adminvote
  - added amx_voteban by ip
o mapchooser
  - added amx_votenextmap to start the nextmap vote immediately
o mapconfig
  - Changed general config files from de_.cfg, cs_.cfg etc... to prefix_xxx.cfg
    (ie prefix_de.cfg, prefix_scoutzknivez.cfg, etc...)
o mapsmenu
  - fixed amx_votemapmenu
o nextmap
  - added "say currentmap"
o plmenu
  - added option "Ban by STEAMID / Ban by IP" to ban menu
  - added amx_unbanmenu
  - added a red @ next to admin names in the menus
o restmenu
  - added KWo's modifications for weapons restrictions for bots
  - players drop restricted weapons at the end of the round
    comment #define DROP_WEAP_END_OF_ROUND in the sma .file if you don't want that
  - fixed a bug in the autobuy/rebuy restriction code
o stats_logging
  - stats are also logged when a player changes his name
o statsx
  - added /top15new, /flop15new, /rankstatsnew (to see some of the new stats)

Includes:
o updated cstrike.inc (conversion of the amxmodx cstrike module into stocks using VexdUM)
o added amxmodx_to_amx.inc
o added message_const.inc

Configuration:
o amx.cfg
  - added amx_reservedslots 0
  - added amx_hideslots 0
  - removed csstats_storagetype
  - removed dodstats_storagetype
  - added amx_langdebug ""

*****************************************************************************
Some natives/stocks were added from AmxModX to facilitate the conversion of 
AmxModX plugins to AmxMod. Here is the list. Credits go to AmxModX Dev Team.

get_weaponid
get_distance_f
arrayset
dir_exists
mkdir
server_changelevel
replace() optimization
format() optimization

mysql_getresult
mysql_field_name

trace_hull
trace_result
get_keyvalue
get_decal_index
call_think
entity_spawn forward

amx_showrcon
amx_reservation=4 code

strtok (C++ code was from AmxModX, converted into a stock for AmxMod)
strbreak (C++ code was from AmxModX, converted into a stock for AmxMod)
is_str_num
split

*****************************************************************************


AMX Mod 2005 RC1
-----------------------------------------------------------------------------
Core:
o added amx_modules command (client command) so that players can know what
  modules are enabled on the server
o added native is_module_running
o added native is_plugin_running
o added native get_modulesnum
o added native is_user_authorized
o added native change_tasktime
o added native get_user_msgname
o added native get_plugincmd
o added native get_plugincmdsnum
o added native get_plugincvar
o added native get_plugincvarsnum
o added native get_cmdaccess
o added native has_user_weapon
o added native set_user_weapon
o added native is_translated
o added native report_error
o moved precache_generic from VexdUM to AMX
o moved math functions to AMX
o fixed get_user_weapon if strip_user_weapon is used (misc_stocks.inc)
o fixed get_players to make it work with DoD
o fixed a bug with JIT
o get_players with "e" flag supports "1", "2", ... ("team number")
  in addition to "TERRORIST", "CT", ...
o 'amx plugins' ('amx list') displays at the end of the list the errors
  of the plugins which have a 'bad load' status
o fixed malformed lines errors (due to blank lines in the lang files)
o removed libstd++ dependancy - special thanks to Jussi "hullu" Kivilinna
o automatically creates the necessary folders if they don't exist
  (write_file, log_to_file, ...)
o added cvar amx_debug
o errors from plugins don't display the line if plugins are running JIT
o you don't need to declare modules in metamod/plugins.ini any more (requires MM(-P) 1.18+)
o fixed menuid/menukey not being reset correctly (get_user_menu)

Fun:
o fixed set/get_user_hitzones
o fixed user_spawn
o added native set_user_deaths_cs
o added native get_user_deaths_cs
o added native set_user_team_cs
o added native get_user_team_cs
o added native set_user_footsteps

CSStats:
o fixed a bug with get_user_vstats and get_user_astats
o added cvar csstats_storagetype: binary (faster) or plain text
o if you modify csstats.dat (plain text), add "changed" at the beginning of the
  file, thus your changes will be taken into account on map change
o added cvar csstats_rankbots
o added cvar csstats_pause

DoD XMod:
o added cvar dodstats_storagetype: binary (faster) or plain text
o added a few natives
o fixed a few things
o modified the way dodstats_rankbots works (bots don't appear in the top15 and
  in the dodstats.dat file, but stats hud messages still take them into account
  (kills, shots, etc...))

Lang:
o fixed the lang files
o added german translation (by KleeneX)

Provided binaries:
o added MetaMod-P 1.18p26 to the default packages
o added GeoIP and Sockets modules to the default packages
  
Plugins:
o admin
  - merged admin_mysql with admin
  - moved vote cvars and amx_show_activity cvar to this plugin
  - added amx_addadmin <name|#userid|authid|ip> <password> <access> <flags>
    (adds the admin to users.ini or database)
  - added amx_makeadmin <name|#userid|authid> [accessflags]: gives admin powers
    to player till the admin disconnects or map changes ("amx_makeadmin <player>"
    to reset his flags; some flags can't be given: immunity, rcon, password)
  - mysql.cfg is executed even if USE_SQL is disabled (for other plugins that use it)
  - if USE_SQL is enabled, admins are dumped into a sql_users.ini file,
    and if the connection to the db can't be established again, the plugin will
    load admins from this file, and if this file doesn't exist, it will load
    admins from users.ini
  - the plugin logs how many admins are loaded
  - added cvar amx_correct_usersfile (if set to 1, when reading users.ini, the
    plugin will modify the lines if the user did some mistakes)
  - added amx_loadadmins and amx_loadsqladmins (server commands); these commands
    reload the admin accounts and the flags of all the players that are on the server
  - added "Loaded map _mapname_" message to the log files when a new map is loaded
o adminchat
  - added amx_tsayy, amx_csayy, amx_fxsay, amx_cfxsay, amx_fxsayy, amx_cfxsayy,
    amx_flicksay, amx_cflicksay, amx_flicksayy, amx_cflicksayy, amx_fsay, amx_fsayy,
    amx_scrollsay, amx_scrollsayy, amx_psayy (and same commands without 'amx_'), amx_sayy
  - made color case insensitive
  - added random color (fe: amx_csay ? message) and possibility to define the color
    (fe: amx_csay !255010240 message)
  - added multilines support using ^n character
  - players can type the english names of the colors in addition to the translated names
  - fixed say_team @message
  - you don't have to use quotes, just type "amx_csay blue this is the message"
o admincmd
  - amx_who: only admins can see the other admins
  - added command amx_name (you don't have to use quotes, just type
    "amx_name john this is the new name")
  - displays reason to the player who is kicked
  - you can slap/slay yourself even if you have immunity
o adminhelp
  - added message "Type 'amx_modules' in the console to see running modules"
  - added #define SHOW_HELPMSG
  - displays "Next Map: selected by vote" (message on join) if mapchooser is enabled
    and no map has been selected
o adminslots
  - this is the slots plugin scripted by f117bomb (with some modifications)
o adminvote
  - vote custom: up to 4 answers
  - displays answers and not "voted for option #1"
  - fixed bug with amx_votemap (added "Choose map:" menu title)
  - fixed: when you launched a vote from the console, sometimes when you closed
    the console you couldn't see the vote
  - cancelling the vote makes the menu disappear on players' screen
  - you can type amx_votemap map1 map2 map3 map4 map5 map6 map7..., it will only
    select the maps that are valid, up to 4
  - added [ip] parameter to amx_voteban ("amx_voteban player ip")
  - added possibility to do a vote to change the value of a cvar
    (fe: "amx_vote mp_friendlyfire 0 1"), at the end of the vote the value of
    the cvar will be changed to the winning value (You need the "g" admin flag)
  - added possibility to do a vote to execute a command (fe: amx_vote csdm_enable 1 0)
    (You need the admin flag required by csdm_enable)
  - when a vote is launched, if a player is watching another menu, the vote won't
    overwrite the menu (it will only overwrite it when there is 6s left); when the
    player closes his menu, he will see the vote (suggested by KWo)
o antiflood
  - changed the way it works
o cmdmenu
  - the plugin won't display translation errors if custom commands are added to:
    cmds.ini, configs.ini, speech.ini
  - added automatic precaching of sound files added to speech.ini (wav and mp3)
  - added amx_plugcmdmenu : type this command, it will display a menu with the list
    of all the plugins that contain commands you have access to, then choose a plugin,
    it will display the list of the commands, then choose a command, the chat will
    be triggered, type in the chat the arguments needed by the command and press enter,
    the command will be executed with the arguments typed in the chat. When the chat is
    triggered, if you press escape (which closes the chat) and you want to type
    a message, you have to type "resetchat" in the chat (or wait 20s); you can also
    type resetchat if you don't want to execute the command any more. If the
    command needs no arguments, don't type anything in the chat and press enter.
  - added amx_plugcvarmenu : type this command, it will display a menu with the list
    of all the plugins that contain cvars you can modify, then choose a plugin,
    it will display the list of the cvars, then choose a cvar, the chat will be
    triggered, type in the chat the new value of the cvar and press enter,
    the value of the cvar will be changed. When the chat is triggered, if you
    press escape (which closes the chat) and you want to type a message, you have
    to type "resetchat" in the chat (or wait 20s) ; you can also type resetchat
    if you don't want to change the value of the cvar any more.
  - added amx_plugcmdmenu [pluginname.amx / plugin name] option so that you can
    bind a key and display a menu with the commands of a plugin automatically
  - added amx_plugcvarmenu [pluginname.amx / plugin name] option so that you can
    bind a key and display a menu with the cvars of a plugin automatically
o imessage
  - set MAX_MESSAGES to 10
o language
  - loadServerLanguage() is now executed in plugin_init() and not in plugin_cfg()
o mapchooser
  - added map history (5 maps)
  - added a map nomination system
  - changed how amx_extendmap_max works
  - added cvar amx_extendround_max
  - added cvar amx_extendround_step
  - added cvar amx_extendwin_max
  - added cvar amx_extendwin_step
  - added cvar amx_mapchooser_mapsloc (0: maps.ini, 1: mapcycle, 2: maps folder)
  - added cvar amx_mapchooser_type (0: random maps from mapcycle/maps.ini/maps folder,
    1: nominations)
  - added cvar amx_nominfromfile
  - added cvar amx_maxnominperplayer
  - if maps.ini is not found, the plugin falls back on the mapcycle file, if mapcycle
    is not found, the plugin falls back on the maps folder
  - when a vote is launched, if a player is watching another menu, the vote won't
    overwrite the menu (it will only overwrite it when there is 6s left);
    when the player closes his menu, he will see the vote (suggested by KWo)
o mapconfig
  - added option to load general map config like cs_.cfg, de_.cfg (_KaszpiR_)
o mapsmenu
  - set MAX_MAPS to 128
  - displays "voted for 'mapname'" and not "voted for option#1"
  - you don't have to type mapname + "description" in the maps.ini file any more,
    mapname is enough
  - cancelling the vote makes the menu disappear on players' screen
  - if maps.ini is not found, the plugin falls back on the mapcycle file, if mapcycle
    is not found, the plugin falls back on the maps folder
  - when a vote is launched, if a player is watching another menu, the vote won't
    overwrite the menu (it will only overwrite it when there is 6s left);
    when the player closes his menu, he will see the vote (suggested by KWo)
o menufront
  - completely rewrote the menu system
  - added command amx_addmenu
  - added command amx_addmenuitem
  - you can now create your own menus (read amx/config/custom_menus.cfg)
  - sounds found in a custom menu are automatically precached
  - added possibility to bind a key to a menu item (read custom_menus.cfg)
  - Team Menu is added to amxmodmenu only if the mod is CS, CS:CZ or DoD
  - Stats Cfg Menu is added to amxmodmenu only if the mod is CS, CS:CZ or DoD
  - Restmenu is added to amxmodmenu only if the mod is CS or CS:CZ
o miscstats
  - fixed amx native error with get_weapon_name
  - added BombPlantedSound,BombDefusedSound,BombFailedSound,GrenadeKillSound,GrenadeSuicideSound
  - added FallKill, Suicide, AirKill, WaterKill, WallShot
  - added automatic precaching of sounds that are enabled
  - added amx_bomb_frags cvar: sets the number of kills awarded for a successful
    bomb plant or defusal (needs Fun or VexdUM)
  - loads stats.ini in plugin_precache
  - sounds won't be played to players who are connecting
  - removed display of HS HUD messages if the weapon is the knife
  - fixed c4 countdown
  - added BombCountHUD,KillingStreakChat,KillingStreakHUD,KillingStreakEndHUD,KillingStreakSay (by KWo)
  - delayed or disabled some HUD messages using 3 and 4 channels for "just killed" players, to prevent
    these messages from overwriting the attackers and victims list (by KWo and KRoT@L)
  - removed hs, knife, airkill, waterkill messages if it's a suicide
  - if VexdUM is enabled, the plugin registers bomb events if a bomb target entity
    is found and not by checking the name of the map (de_ or csde_)
o nextmap
  - mp_chattime setting is taken into account and not set by the plugin any more
  - changed nextmap message if mapchooser is enabled
o pausecfg
  - enabled amx_on and amx_off commands by default
  - removed some plugins to keep when amx_off is executed
o plmenu
  - fixed actionTeamMenu if the admin changed his team using the menu
  - modified changeteam using Fun or VexdUM (if enabled)
  - modified amx_teammenu (to support CS and DoD, and spectator team)
  - displays "Slap with 0 damage" instead of "Slay" when you open amx_slapmenu
  - the plugin won't display translation errors if custom commands are added to clcmds.ini
  - ban by ip if authid is valve_id_lan or HLTV (by MistaGee)
  - you can slap/slay yourself even if you have immunity
  - fixed team menu display
o plugmod manager
  - modifies amx/config/plugins.ini and amx/config/modules.ini
    according to the contents of amx/plugins and amx/modules folders
o restmenu
  - fixed autobuy and rebuy: players can use autobuy and rebuy but it will only
    buy weapons which are not restricted
  - fixed a means to bypass restrictions with a buy script
  - changed Gali to Galil (in the menu)
o statsx
  - added flop15
  - loads stats.ini in plugin_precache (in case statscfg is not running)
  - enabled full stats
  - fixed a bug in the attackers list
  - removed EndPlayer and EndTop15
  - fixed motd formatting
  - fixed player names that were containing html tags and messing up the top15
o timeleft
  - added automatic mapchange if timeleft is 0 and there are no players on the server
  - timeleft should now be more accurate
o dodstats
  - changed the rank calculation
o dodx_stats
  - added multilingual system
  - removed EndPlayer and EndTop15
  - added GrenadeKillSound, GrenadeSuicideSound, Suicide, AirKill, WaterKill
  - added flop15
  - added automatic precaching of sounds that are enabled
  - sounds won't be played to players who are connecting
  - fixed a few things
  - fixed motd formatting
  - fixed player names that were containing html tags and messing up the top15
o removed welcomemsg
o added ff_manager for CS and DoD
o removed WON support

Includes:
o amxmod.inc
  - removed #include <fun>
o amxmisc.inc
  - added is_user_admin(id)
  - fixed cmd_access which wasn't translating the help message
  - modified stock access(id,level)
  - added colored_menus()
  - modified build_path (supports $basedir, $configdir, $langdir, $logdir,
    $modulesdir, $pluginsdir)
o amxconst.inc
  - added AMX_VERSION "2005rc1"
  - added #define CSW_GALIL 14
o added cstrike.inc (conversion of the amxmodx cstrike module into stocks using VexdUM)
o added misc_stocks.inc
o fixed get_grenade_id in Xtrafun_To_Vexd.inc and VexdUM_stocks.inc

Configuration:
o amx.cfg
  - set amx_default_access to z
  - set amx_time_voice to 0
  - set amx_reservation to 0
  - set amx_vote_ratio to 0.50
  - set amx_extendmap_max to 3
  - added amx_mapsmenu_mapsloc 0
  - added amx_mapchooser_mapsloc 0
  - added amx_mapchooser_type 0
  - added amx_nominfromfile 0
  - added amx_maxnominperplayer 1
  - added amx_extendround_max 3
  - added amx_extendround_step 3
  - added amx_extendwin_max 3
  - added amx_extendwin_step 3
  - added amx_manage_plugins 0
  - added amx_manage_modules 0
  - added amx_correct_usersfile 1
  - added amx_bomb_frags 3 (CS package)
  - added csstats_storagetype, csstats_rankbots, csstats_pause (CS package)
  - added DoD XMoD cvars (DoD package)
  - added amx_debug 0
o clcmds.ini
  - changed '"c" - execute on selected player' to '"c" - execute from selected player'
  - added this message (in the other ini files too):
    ; NOTE: Access level defined here overrides the access level of the command
    ; (if executed from admin console), so use with care.
o configs.ini
  - updated the list of config files (for CS package)
  - added ogl_dod cfg file (for DoD package)
o cvars.ini
  - added some cvars
  - added a separation for CS/DoD cvars
o maps.ini
  - added CS 1.6 / DoD maps
o modules.ini
  - added GeoIP and Sockets modules
  - added DoD XMoD to the DoD package
o plugins.ini
  - changed the order of the plugins
  - added separations for CS and DoD plugins
o users.ini
  - added some help
  - enabled loopback by default
o added custom_menus.cfg
o added paths.ini

Misc:
o compile.bat/compile(linux)
  - modified so that it also compiles sma files from examples folder and it
    creates source and default folders if they don't exist
  - displays only the warnings/errors, if any
o added compile_drag&drop.bat
o added GeoIP.dat to the modules folder
o added config files (from configs.ini) to the root of the packages
o created an AMX sound package
o created 3 packages: amx-CS, amx-DoD, amx-lite
o translated the doc into french (by KRoT@L)
o translated the config files into french (amx-2005.1-fr, by KRoT@L)
o translated the doc into german (by KleeneX)
o translated the config files into german (amx-2005.1-fr, by KleeneX)


AMX Mod 0.9.9 BETA
-----------------------------------------------------------------------------
Core:
o added the Just-In-Time (JIT) Compiler for Windows and Linux; this allows
  plugins to be executed 10+ times faster (can be disabled globally or for
  specific plugins)
  This is thanks to the NASM port (used for both Windows and Linux versions)
  by G.W.M. Vissers from Eternal-Lands.com :)
o added the multilingual support: each player can have AMX displaying
  messages in a different language (currently supported in the default
  plugins: English, French -- feel free to add more), see the Documentation
  for more details
o upgraded Compuphase's SmallC core to v2.6: it is recommended to recompile
  all your plugins with the new compiler (not compulsory though)
o reverted back to 0.9.3's modules management: they have to be declared
  both in MetaMod and AMX again
o new interface version for modules (those compiled before will not work):
  - now modules can know if a plugin is paused (and the use of this feature
    is highly recommended for those implementing forwards)
  - modules using AMX_RAISEERROR will have to #define MODULE_NAME, so that
    AMX can be more verbose when run-time errors occur
  - one more parameter must be added to LOAD_AMXSCRIPT calls
    (1: try to use JIT, 0: don't)
o fixed the use of the 'amx_basedir' localinfo (now AMX can really be run
  from another directory than addons/amx)
o fixed CSStats not returning weapon names on first map

Directories:
o config files (*.ini, *.cfg, *.txt) have moved from addons/amx to
  addons/amx/config (including plugins.ini)
o modules (*.dll, *.so) have moved from addons/amx/dlls to addons/amx/modules
  (now only AMX is in addons/amx/dlls)
  Notes: - CSStats' data file csstats.dat has moved to amx/modules as well
         - you don't have to specify the path anymore in modules.ini

Provided binaries:
o added MetaMod to the default package with a sample plugins.ini file
o added one third-party module to the default package: Vexd 0.9.9
  (disabled by default) (plugins using this one must be recompiled)

Plugins:
o fixed scrollmsg and imessage plugins so that %hostname% works correctly
  with Steam servers
o added StatsX, an improvement by XAD from the previous stats plugin (which
  has been removed)
o added MapConfig, allowing to have custom map config files
o default plugin 'admincmd' (Admin Commands) do not provide amx_banid and
  amx_banip anymore, now amx_ban can ban users (by AuthID or IP), AuthIDs
  and IPs itself
o rearranged the plugins sources directory structure

Configuration:
o added csstats info into amx.cfg for rank tracking and resetting
o added more examples, info and recommendations into users.ini
o enabled popular csstats features by default in stats.ini:
  - say /statsme, /rank, /top15, /stats, /hp
  - show attackers, victims, killer, killer hp&ap
  - show stats at end of map
    (do not manually edit: use 'amx_statscfg' or 'amx_statscfgmenu')
o added URL for DoD XMod into modules.ini
o added note for disabling plugins into plugins.ini
o disabled welcomemsg.amx by default for Steam version in plugins.ini

Documentation:
o added the HTML documentation, also available on the website


AMX Mod 0.9.8 Pre-Alpha
-----------------------------------------------------------------------------
o Updated to support new metamod interface [OLO]
o Fixed the restriction menu bug [XAD]


AMX Mod 0.9.7 BETA
-----------------------------------------------------------------------------
o added support for listenservers, all you need is
  "loopback" "" "abcdefghijkmnopqrstu" "de" entry in users.ini file
o added read_datanum() native function
o added CS_DeathMsg event which fixes last damage issue
o added amx_csay command; you can now specify if you want to show
  names with hud messages (to set in plugin sources)
o added forward client_authorized() called when a client get valid steam id
o added formating to MOTD window for top15, statsme and rank
o made adminslots, admin, admin_mysql using client_authorized()
o removed support for amx_real_res_slots (for HLSW)
o rebuilded adminslots, fixed hide slots issue; now there is only one
  cvar - amx_reservation (see plugin comments for more details)
o modules used by AMX don't have to be put in the
  metamod/plugins.ini file anymore
o made that stats in rank are not saved if get_score returns cellmin
o made read_data() to return values in a requested format
  (should help in debugging since all values can be returned as string)
o made that on a module error a server exits with a proper message
o improved commands handling, now high number of commands/AMX plugins
  shouldn't affect a server overload
o fixed force_unmodified() for files different from "wav" and "mdl"
o fixed crashes caused by missing plugins with left entries in plugins.ini
o fixed that register_cvar() didn't set an initial string for a cvar
o fixed weapon restriction plugin (now can block buy commands in CS 1.6)
o removed get_user_wonid() native function
o for custom rank's points calculation (by default: kills - deaths) you
  must set "csstats_score" localinfo (f.e. to "addons/amx/csstats.amx")


AMX Mod 0.9.6 BETA
-----------------------------------------------------------------------------
o fixed entry in "amxmisc.inc" file about a command access
o fixed admin access when an account was set for an IP
o fixed cancel vote report in admin vote plugin
o fixed say /hp and killer displaying in stats plugin
o brought back old compiler and initializing local variables by default
o improved compile plugins script for linux
o fixed parsing names containing '<' and '>' chars with parse_loguser(...)


AMX Mod 0.9.5 BETA
-----------------------------------------------------------------------------
o fixed reserved slots, also not used are hidden now
o fixed boundary checks
o fixed pause( ... ) and unpause( ... ) which crash on unknown plugin name
o fixed pause plugins plugin
o added stock functions to "amxmisc.inc" and new constants to "amxconst.inc"
  . get_basedir( ... )
  . build_path( ... )
  . show_activity( ... )
  . get_logfile( ... )
o admin command "amx_plugin" is changed to "amx_pausecfg"
o added "amx_banid", "amx_banip" and changed "amx_ban"
o fixed admin logging when name is changed
o by default compiler doesn't initialize local variables to zero
  (option can be turned on with -z flag)
o general rewrite/tweak for all default plugins
o server commands "amx cmds" and "amx cvars" give now more detailed info
o admin must now have all flags of command to gain an access to it
o added amx_logdir localinfo which specifies logging directory for
  log_to_file(...) (default plugins has been updated to obey that setting)
o added "amx_basedir" localinfo by which plugins know a path
  to configuration files (resolves problem with running the same AMX on
  different ports with different settings, accounts and plugins)
o modified admin, admin_mysql and slots reservation
  plugins to work also on CS 1.6 (you have to edit source first)
o extended functionality of file_size(...) native
o added native functions to support public variables (introduced them
  with stats and stats configuration plugins)
  . xvar_exists( ... )
  . get_xvar_id( ... )
  . get_xvar_num( ... )
  . get_xvar_float( ... )
  . set_xvar_num( ... )
  . set_xvar_float( ... )
  . isalpha(...)
  . isdigit(...)
  . isalnum(...)
  . isspace(...)
o added Miscellaneous Stats plugin for Counter-Strike which constains
  . multikill announcement
  . bomb events
  . killing streak
  . enemy remaining
  . round counter
  . italy bonus kill
  . knife kill
  . headshot kill
  . greanade kill
  . last man
  . double kill
  . player name
o added some stats to Stats plugin
  . most damage
  . most kills
  . team score
  . rank info


AMX Mod 0.9.4 BETA
-----------------------------------------------------------------------------
o fixed that stats are not shown if you survive a round
o fixed get_user_money(...) under linux in fun module
o fixed issue with amx_nextmap when mp_chattime was set to 0
o plugin nextmap chooser uses now maps.ini as configuration file
o admin_mysql.amx is now a seperate plugin (disable admin.amx)
o name admin.cfg is changed to amx.cfg
o admin accounts are moved to users.ini (there is no amx_admin command)
o logd and udp modules are no more in default package
o moved changelog.txt to readme.txt
o replaced adminmenu.amx (amx_menu cmd) with several menus (amxmodmenu cmd)
o changed nextmap plugin to obey mapcycle (you can still use the old style)
o in register_menuid(...) you can specify if a menu from outside plugin
  can be grabed by a menu command (fixes serveral problems with voting)
o added weaponstats2, latency and time logging to stats logging plugin
o added amx_cancelvote command (removes all tasks with 99889988 id)
o added "say @ ..." commands to adminchat plugin (CM like)
o changed amx_ppause command to main amx_plugin (with several options)
o added two new flags for set_task(...)
o added cvar csstats_maxsize (by default set to 3500) which
  resets stats when number of entries is reached
o combined console and menu version of restrict weapons plugin
o fixed bug in fun module with give_item(...) (thx EJ)
o added amx_statscfg and amx_statscfgmenu (affects menu front end)
  commands to stats configuration plugin
o moved amx_dpause and amx_addoption to the main commands amx_plugin and
  amx_statscfg (plugins which use one of these commands have to be edited)
o added native functions:
  . format_time(...)
  . parse_time(...)
  . get_systime(...)
  . task_exists(...)
  . power(...)
  . sqroot(...)
  . time(...)
  . date(...)
  . tickcount(...)
  . vaultdata_exists(...)
  . get_vaultdata(...)
  . set_vaultdata(...)
  . remove_vaultdata(...)


AMX Mod 0.9.3 BETA
-----------------------------------------------------------------------------
o fixed imessage plugin which spamed the server with
  hudmessages when amx_freq_imessage was set to 0
o fixed pausing first plugin when "amx pause" was called from server console
o fixed format-string bug in log_message native function which could
  be used to gain a remote shell for people who have access to rcon
o added get last bullet hit to get_user_origin(...) (added by Mike Cao)
o added format_args(...) native which formats arguments
  of function to one string
o cvar csstats_rank sets mode of ranking: 0 by nick, 1 by authid and 2 by ip
o improved Pause Plugins plugin (added amx_ppause and amx_pausemenu cmds.)
o added Stats Settings plugin for better server managment
  (use amx_statscfg command from that plugin to enable proper stats)
o made amx_psay command to be HLSW tool compatible
o added native functions:
  . is_user_hltv( ... )
  . is_linux_server()
  . is_dedicated_server()
  . read_dir( ... )
  . read_logdata( ... )
  . read_logargc()
  . read_logargv( ... )
  . parse_loguser( ... )
  . register_logevent( ... )
o added forward function plugin_log() called on log message
o you can now specify connecting port in mysql module (added by BigDog)
o fixed stats plugin which could not display all players in top15 list
o made admin base plugin to check user access on name change
o added random direction of slaping in user_slap(...) native


AMX Mod 0.9.2 BETA
-----------------------------------------------------------------------------
o added inconsistent file checking for sounds and models to AMX
o improved searching for target in admin commands
o removed timeleft/nextmap flood exploit (changed order in plugins.ini)
o fixed bug with gathering information from user at last slot
o added cvar csstats_reset to reset stats on map change
o fixed issue with get_user_team(...) in DOD
o fixed option under flag "f" in get_players(...)
o fixed option under flag "k" in find_player(...)
o improved scrolling messaging (no overflows)
o fixed bug when task was self-removing during execution
o moved logs to new folder and changed theirs format (edited plugins are:
  admin, adminchat, admincmd, adminslots, adminvote, mapextend)
o new plugin: information messages (see admin.cfg for more details)
o fixed issue in mapextend plugin when on server were no players
o added more cvars settings to admin.cfg from default plugins
o fixed admin slots plugin and added new option to it
o fixed timeleft plugin to not hang up during counting down
o reduced frequency of notifing by fun module
o added notifing for health, armor and frags changes
o new native functions:
  . set_cvar_flags(const cvar[], flags)
  . get_cvar_flags(const cvar[])
  . remove_cvar_flags(const cvar[], flags = -1)
o new natives for strings:
  . strtolower(string[]) - converts string to lower case
  . strtoupper(string[]) - converts string to upper case
o combined AMX with MetaSmall so there is only AMX Mod
o Strings, files and floats modules has been moved to AMX Mod code
o plugin adminvote uses now cvar to set voting session, so other plugins
  can check if it is still in progress or when was the last vote
o made admin commands to accept also '#userid' as target
o amx_ban command works now also on LAN servers
o changed cfg in menu.cfg to perform an action on player by '#userid'
o amx_nextmap and amx_timeleft now are visible in server status
o added amx_show_activity cvar to admincmd plugin and adminvote
o compiled AMX with newest metamod 1.14 (so it works with CS 1.6)
o removed execution of amx_vote results
o added to fun module (only for Counter-Strike):
  . get_user_money(...)
  . set_user_money(...)
o replaced mapextend plugin with more powerful mapchooser plugin
  (configuration for that plugin is in admin.cfg)
o added to csstats module
  . get_user_wrstats(...)
o changed name of function get_user_lstats(...) to get_user_rstats(...)
  (however old still remains for backward comaptibility)
o added some constants to amxconst.inc file
o added amx_unban command to admincmd plugin
o fixed issue in adminmenu when there were diff. access flags set for
  cvars and server commands
o fixed fun module to reset rendering on client respawn


AMX Mod 0.8.4 BETA
-----------------------------------------------------------------------------
o moved 19 natives, like give_item(...), set_user_rendering(...)
  or set_user_godmode(...), to seperate "fun" module
o added localinfo for metasmall which specifies metasmall.ini
  (+localinfo ms_metasmall metasmall.ini)
o removed "Fixed" module from default package
o changed localinfo amx_plugins and localinfo csstats to be
  specified only by filename and not by full path
o added csstats.amx plugin by which you can rank players in top15
o fixed issue with lenght protection on replace native in string
  module
o fixed issue with get_clcmd(...) when flag was set to 0
o you can now specify if modules for metasmall have to be loaded
  only once or initialized on every map change
o moved operations on files to seperate module for metasmall
o new flags for function get_players(...):
  . "f" - match with part of name.
  . "g" - ignore case sensitivity.
o added new functions for metasmall engine:
  . build_pathname
  . get_modname
  . print_console
o in function get_user_time(...) you may now specify playing time
  without connection idle
o function get_playersnum(...) can now also count connecting players
o new native functions
  . is_user_connecting(...)
  . get_srvcmd(...)
  . console_print(,...)
  . console_cmd(...)
  . register_concmd(...)
  . get_concmd(...)
  . get_srvcmdsnum(...)
  . get_flags(...)
o added new include file amxmisc.inc
o made mysql module to not open new connection each time if such
  already exists but return just its id to use with sql natives
o fixed reset stats on player connection issue in CSStats module
o fixed get_pluginsnum() function
o added "amx cmds" command, displaying server commands registered
  by plugins
o made registered server commands case insensitive
o many improvments and some fixes in default scripts:
  . stats         : new cmds say /stats and say /statsme
  . adminvote     : fixed bug with votes counting and changed keys
  . welcomemsg    : added to default package
  . stats_logging : added to default package
  . adminhelp     : added to default package
  . timeleft      : timeleft and thetime is announced by voice
  . admincmd      : added amx_who, amx_slap, amx_pause and amx_leave
  . adminchat     : added server commands and improved amx_chat
  . admin         : added amx_default_access
  . adminslots    : rebuilded plugin
  . ppause        : pause and unpause plugins on the fly
  . general clean up

NOTE: Due to changes in metasmall engine all previous dlls are
  incompatible, replace them with these in downloaded package.


AMX Mod 0.7.3 BETA
-----------------------------------------------------------------------------
o made menus to be mod independent
o added "amx cvars" command, displaying CVars registered by plugins
o fixed bug in string module with native add(...)
o changed way of dealing with no MetaSmall (plugins are just unloaded
  from MetaMod with some info) in AMXMod and CSStats modules
o fixed crash on calling get_clcmd for command with empty description
o added localinfo amx_plugins where you can specify filename with
  plugins list to load on HLDS command line
  f.e. +localinfo amx_plugins addons/amx/plugins/plugins.ini
o added localinfo csstats to specify stats data file :
  +localinfo csstats addons/metasmall/csstats.dat
o fixed server crash when using plugin_end
o fixed native remove_task (sometimes not removing tasks properly)
o moved CS stats to a MetaMod plugin & MetaSmall module
  (has to be defined in addons/metamod/plugins.ini AND in
  addons/metasmall/modules.ini, like AMX)
o plugins adminchat, admincmd and adminvote can accept WONIDs
o fixed a syntax error in menu.cfg


AMX Mod 0.7 BETA
-----------------------------------------------------------------------------
o added MetaSmall 0.1 engine and modules :
  . string
  . fixed
  . float
  . mysql
o changed AMX to be both a MetaMod plugin and MetaSmall module
o changes and fixes in plugins :
  . adminslots : now kicks properly
  . adminvote  : added amx_vote_delay cvar (min. time between votes)
  . mapextend  : fixed divide by zero
  . admincmd   : fixed amx_ban command
  . some other fixes :-)
o added natives :
  . get_user_godmode(index)
  . set_user_noclip(index)
  . get_user_noclip(index)
  . get_user_wonid(index)
  . mysql_connect(host[],user[],pass[],dbname[],error[],maxlength)
o new flag in function find_player(...):
  . "l" - ignores case sensitivity
o fixed natives headers in amxmod.inc :
  . get_stats(index,stats[8],bodyhits[8],name[],len)
  . get_statsnum()


AMX Mod 0.6.1 BETA
-----------------------------------------------------------------------------
o fixed linux cvar & float issues that broke many things in 0.6
o removed avlist plugin
o added menu.cfg file for adminmenu plugin
o fixed admin_sql plugin when mysql query couldn't be performed


AMX Mod 0.6 BETA
-----------------------------------------------------------------------------
o added forward plugin_end(), which is called just before
  plugin unloading
o added formatting in functions like format(dest[],len,text[],...)
o added native log_to_file(file[])
o added native get_user_deaths(index)
o added stats natives :
  . get_user_wstats(index,wpnindex,stats[8],bodyhits[8])
  . get_user_stats(index,stats[8],bodyhits[8])
  . get_user_vstats(index,vic,stats[8],body[8],wpnname[]="",len=0)
  . get_user_astats(index,wpn,stats[8],body[8],wpnname[]="",len=0)
  . reset_user_wnstats(index)
  . get_stats(index,stats[8],bodyhits[8])
  . get_statsnum(index,stats[8],bodyhits[8])
o added mysql support :
  . native sql_query(query[])
  . native sql_newquery(sql,query[])
  . native sql_nextrow(sql)
  . native sql_getfield(sql,fieldnum,dest[],maxlength)
  . native sql_free(sql)
o native get_user_team(index, team[]="", len=0) now
  returns team index from mod
o native get_user_attacker(index,...) also returns hit body part
o changed parameters list in native set_task(...)
  (plugins must be recompiled)
o changed parameters list in native read_file(...)
  (plugins must be recompiled)
o copied values will always be trunked to given length
  (the error won't be raised as it is now)
o last parameter in native get_user_ip(index,ip,[],len,p=0) sets
  if ip address have to be get with port or not
o if there is less arg to set from parse the error is not raised


AMX Mod 0.5 BETA
-----------------------------------------------------------------------------
o added native get_user_weapon(index,&clip,&ammo)
o added native get_user_ammo(index,weapon,&clip,&ammo)
o added native get_weaponname(weapon_id,weapon[],iLen)
o added native get_user_listening(iReceiver,iSender)
o added native set_user_listening(iReceiver,iSender,bListen)
o added native get_clcmdsnum( flags = 0)
o added native get_clcmd(index, flag, cmd[], iLen1, info[], iLen2)
o added native replace(text[],iLen,what[],with[])
o added native get_maxplayers()
o added native get_pluginsnum()
o added native get_plugin(index,filename[], iLen1, name[],iLen2,
  version[],iLen3,author[],iLen4,status[],iLen5)
o changed native get_user_weapons(index,iwpns[32],&inum)
o changed native get_user_attacker(index,&weapon)
o changed native get_user_origin(index,origin[3],mode=0)
o changed ADMIN flags in amxconst.inc
o replaced user_glow with set_user_rendering (more options to set)
o now when bots join to server, natives client_connect and
  client_putinserver are called
o native show_motd can now display files (send filename
  as body parameter)
o fixed bug in checking length of parameter in read_data
o fixed bug in parse native where arguments weren't 0 terminated
o added many administrating/managment scripts


AMX Mod 0.4 BETA
-----------------------------------------------------------------------------
o added native engclient_print(id,type,message[], ...)
o added native parse(text[], ... )
o added native random_float(Float:a,Float:b)
o added native random_num(a,b)
o added native remove_quotes(text[])
o added native file_exists(text[])
o added native delete_file(text[])
o added native read_file(file[],line,text[],iLen)
o added native write_file(file[],text[],line=-1)
o added native get_user_attacker(index)
o added native Float:get_user_aiming(index,&id,&body,dist=9999)
o added native cvar_exists(cvarname[])
o added native register_plugin(title[],version[],author[])
o added server command: amx < command > [ parameter ]
o changed parameters for native function user_glow(...)
o changed parameters for native function register_cvar(...)
o changed flags for find_player(...)
o changed flags for get_players(...)
o fixed set_cvar_string/float natives
o removed native check_user_flags(...)
o more examples of plugins: admin, mirror damage, last man
