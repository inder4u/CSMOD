function showdiv(div) {
	if (div == 'won') {
		document.getElementById('won').style.display='block';
		document.getElementById('steam').style.display='none';
	}
	else {
		document.getElementById('steam').style.display='block';
		document.getElementById('won').style.display='none';
	}
}